﻿namespace ngulieu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox_entity = new System.Windows.Forms.ComboBox();
            this.button_generate = new System.Windows.Forms.Button();
            this.button_read_file = new System.Windows.Forms.Button();
            this.richTextBox_display = new System.Windows.Forms.RichTextBox();
            this.comboBox_attribute = new System.Windows.Forms.ComboBox();
            this.comboBox_opinion = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // comboBox_entity
            // 
            this.comboBox_entity.BackColor = System.Drawing.Color.White;
            this.comboBox_entity.FormattingEnabled = true;
            this.comboBox_entity.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.comboBox_entity.Items.AddRange(new object[] {
            "Xin chào",
            "ABC",
            "ASASA",
            "ÁDFASDA"});
            this.comboBox_entity.Location = new System.Drawing.Point(46, 398);
            this.comboBox_entity.Name = "comboBox_entity";
            this.comboBox_entity.Size = new System.Drawing.Size(121, 21);
            this.comboBox_entity.TabIndex = 0;
            this.comboBox_entity.Text = "Choose entity";
            this.comboBox_entity.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button_generate
            // 
            this.button_generate.BackColor = System.Drawing.Color.White;
            this.button_generate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_generate.Location = new System.Drawing.Point(198, 311);
            this.button_generate.Name = "button_generate";
            this.button_generate.Size = new System.Drawing.Size(121, 57);
            this.button_generate.TabIndex = 1;
            this.button_generate.Text = "Generate";
            this.button_generate.UseVisualStyleBackColor = false;
            this.button_generate.Click += new System.EventHandler(this.button1_click);
            // 
            // button_read_file
            // 
            this.button_read_file.BackColor = System.Drawing.Color.White;
            this.button_read_file.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_read_file.Location = new System.Drawing.Point(46, 328);
            this.button_read_file.Name = "button_read_file";
            this.button_read_file.Size = new System.Drawing.Size(121, 23);
            this.button_read_file.TabIndex = 2;
            this.button_read_file.Text = "Read .txt file";
            this.button_read_file.UseVisualStyleBackColor = false;
            this.button_read_file.Click += new System.EventHandler(this.button2_click);
            // 
            // richTextBox_display
            // 
            this.richTextBox_display.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox_display.Location = new System.Drawing.Point(12, 12);
            this.richTextBox_display.Name = "richTextBox_display";
            this.richTextBox_display.Size = new System.Drawing.Size(500, 268);
            this.richTextBox_display.TabIndex = 3;
            this.richTextBox_display.Text = "";
            // 
            // comboBox_attribute
            // 
            this.comboBox_attribute.BackColor = System.Drawing.Color.White;
            this.comboBox_attribute.FormattingEnabled = true;
            this.comboBox_attribute.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.comboBox_attribute.Items.AddRange(new object[] {
            "Xin chào",
            "ABC",
            "ASASA",
            "ÁDFASDA"});
            this.comboBox_attribute.Location = new System.Drawing.Point(198, 398);
            this.comboBox_attribute.Name = "comboBox_attribute";
            this.comboBox_attribute.Size = new System.Drawing.Size(121, 21);
            this.comboBox_attribute.TabIndex = 4;
            this.comboBox_attribute.Text = "Choose attributes";
            this.comboBox_attribute.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox_opinion
            // 
            this.comboBox_opinion.BackColor = System.Drawing.Color.White;
            this.comboBox_opinion.FormattingEnabled = true;
            this.comboBox_opinion.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.comboBox_opinion.Items.AddRange(new object[] {
            "Xin chào",
            "ABC",
            "ASASA",
            "ÁDFASDA"});
            this.comboBox_opinion.Location = new System.Drawing.Point(349, 398);
            this.comboBox_opinion.Name = "comboBox_opinion";
            this.comboBox_opinion.Size = new System.Drawing.Size(121, 21);
            this.comboBox_opinion.TabIndex = 5;
            this.comboBox_opinion.Text = "Choose opinion";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(524, 447);
            this.Controls.Add(this.comboBox_opinion);
            this.Controls.Add(this.comboBox_attribute);
            this.Controls.Add(this.richTextBox_display);
            this.Controls.Add(this.button_read_file);
            this.Controls.Add(this.button_generate);
            this.Controls.Add(this.comboBox_entity);
            this.MaximumSize = new System.Drawing.Size(540, 486);
            this.MinimumSize = new System.Drawing.Size(540, 486);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tool";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_entity;
        private System.Windows.Forms.Button button_generate;
        private System.Windows.Forms.Button button_read_file;
        private System.Windows.Forms.RichTextBox richTextBox_display;
        private System.Windows.Forms.ComboBox comboBox_attribute;
        private System.Windows.Forms.ComboBox comboBox_opinion;
    }
}

