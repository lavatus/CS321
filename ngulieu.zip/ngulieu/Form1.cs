﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ngulieu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string txt_file_name; 
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_click(object sender, EventArgs e)
        {
            string combine_text = comboBox_entity.Text + " " + comboBox_attribute.Text + " " + comboBox_opinion.Text + "\n";
            richTextBox_display.Text += "\n" + combine_text;
            System.IO.File.WriteAllText(@"..\..\new_text_file.txt", richTextBox_display.Text);
        }

        private void button2_click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fileName;

                fileName = dlg.FileName;
                txt_file_name = fileName;
                string Text = System.IO.File.ReadAllText(@fileName);
                richTextBox_display.Text = Text;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
